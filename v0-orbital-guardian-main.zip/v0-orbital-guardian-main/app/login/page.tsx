"use client"

import LoginCard from "@/components/login-card"

export default function LoginPage() {
  return (
    <section className="relative min-h-dvh overflow-hidden">
      {/* Background image covers the whole screen */}
      <img
        src="/images/space-debris-2.webp"
        alt="Earth from space with a field of satellite debris"
        className="absolute inset-0 h-full w-full object-cover object-center contrast-110 saturate-125"
        style={{
          imageRendering: "auto",
          backfaceVisibility: "hidden",
          transform: "translateZ(0)",
        }}
      />

      {/* Overlay for readability */}
      <div className="absolute inset-0 bg-black/30" />

      {/* Welcome text at top-center */}
      <header
        className="pointer-events-none absolute left-1/2 top-8 -translate-x-1/2 text-center text-white drop-shadow-lg"
        aria-label="Welcome message"
      >
        <h1 className="text-balance font-semibold tracking-tight text-2xl md:text-4xl">Welcome to Orbital Guardian</h1>
        <p className="mt-2 text-pretty text-sm md:text-lg text-white/90">
          Space debris monitoring and collision‑alert platform
        </p>
      </header>

      {/* Centered login card, pushed down so it never overlaps the header */}
      <div className="relative z-10 flex min-h-dvh items-start justify-center p-6 md:p-10 pt-48 md:pt-56 pb-16">
        <LoginCard defaultMode="signup" />
      </div>
    </section>
  )
}
