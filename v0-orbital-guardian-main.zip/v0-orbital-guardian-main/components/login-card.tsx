"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

type Mode = "signup" | "signin"
export default function LoginCard({ defaultMode = "signin" }: { defaultMode?: Mode }) {
  const [mode, setMode] = useState<Mode>(defaultMode)
  const [showPassword, setShowPassword] = useState(false)

  const isSignIn = mode === "signin"

  return (
    <Card
      className={cn(
        "w-full max-w-sm h-[560px] md:h-[640px] flex flex-col", // reduce height on small screens to avoid header overlap
        // translucent dark-blue card with blur and soft border
        "bg-login-card/60 backdrop-blur-md text-login-card-foreground border-white/10 shadow-2xl",
      )}
    >
      <CardHeader className="pb-2">
        <CardTitle className="text-pretty">{isSignIn ? "Initialize Mission Control" : "Create your account"}</CardTitle>
        <CardDescription className="text-login-card-foreground/80">
          {isSignIn ? "Enter your credentials to access the console." : "Get started by setting up your profile."}
        </CardDescription>
      </CardHeader>

      <CardContent className="flex-1">
        {/* Social auth options */}
        <div className="grid gap-2 mb-4">
          <Button
            type="button"
            variant="secondary"
            className="w-full bg-login-card-foreground/10 text-login-card-foreground hover:bg-login-card-foreground/15"
            onClick={() => console.log("[v0] Continue with Google")}
          >
            <span className="mr-2 inline-block" aria-hidden>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <path
                  fill="#EA4335"
                  d="M12 10.2v3.9h5.5c-.2 1.3-1.7 3.6-5.5 3.6-3.3 0-6-2.7-6-6s2.7-6 6-6c1.9 0 3.2.8 3.9 1.5l2.7-2.6C16.9 3 14.7 2 12 2 6.9 2 2.8 6.1 2.8 11.2S6.9 20.5 12 20.5c7 0 9.7-4.9 9.7-7.3 0-.5-.1-.9-.2-1.3H12z"
                />
              </svg>
            </span>
            Continue with Google
          </Button>
          <Button
            type="button"
            variant="secondary"
            className="w-full bg-login-card-foreground/10 text-login-card-foreground hover:bg-login-card-foreground/15"
            onClick={() => console.log("[v0] Continue with Facebook")}
          >
            <span className="mr-2 inline-block" aria-hidden>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <path d="M22 12a10 10 0 1 0-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.5 1.5-3.88 3.78-3.88 1.1 0 2.25.2 2.25.2v2.48h-1.27c-1.25 0-1.63.78-1.63 1.58V12h2.78l-.44 2.89h-2.34v6.99A10 10 0 0 0 22 12z" />
              </svg>
            </span>
            Continue with Facebook
          </Button>
        </div>

        <form className="grid gap-4" onSubmit={(e) => e.preventDefault()}>
          {!isSignIn && (
            <div className="grid gap-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" placeholder="Your name" />
            </div>
          )}

          <div className="grid gap-2">
            <Label htmlFor="email">Email address</Label>
            <Input id="email" type="email" placeholder="you@example.com" />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Input id="password" type={showPassword ? "text" : "password"} placeholder="••••••••" className="pr-10" />
              <button
                type="button"
                aria-label={showPassword ? "Hide password" : "Show password"}
                onClick={() => setShowPassword((v) => !v)}
                className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 rounded-md text-login-card-foreground/70 hover:text-login-card-foreground focus:outline-none"
              >
                {showPassword ? (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M2.1 3.51 3.5 2.1l18.4 18.39-1.41 1.41-3.04-3.04A10.6 10.6 0 0 1 12 20C6.73 20 2.39 16.64 1 12c.43-1.32 1.11-2.55 2-3.62l-.9-.87zM12 6c5.27 0 9.61 3.36 11 8-.38 1.18-.97 2.28-1.73 3.25l-2.16-2.16c.54-.82.86-1.8.86-2.86A5 5 0 0 0 9.77 8.28L7.4 5.91C8.85 5.35 10.39 6 12 6Zm-1.48 4.09 4.39 4.39c-.33.93-1.2 1.59-2.21 1.59a2.7 2.7 0 0 1-2.7-2.7c0-1.01.66-1.88 1.52-2.28Z" />
                  </svg>
                ) : (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 5c-5 0-9.27 3.11-11 7 1.73 3.89 6 7 11 7s9.27-3.11 11-7c-1.73-3.89-6-7-11-7Zm0 12a5 5 0 1 1 0-10 5 5 0 0 1 0 10Zm0-2.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z" />
                  </svg>
                )}
              </button>
            </div>
          </div>

          {isSignIn && (
            <div className="flex justify-end">
              <button
                type="button"
                className="text-sm text-login-card-foreground underline-offset-2 hover:underline"
                onClick={() => console.log("[v0] Forgot password")}
              >
                Forgot password?
              </button>
            </div>
          )}

          <Button type="submit" className="w-full mt-2">
            {isSignIn ? "Initialize Mission Control" : "Create account"}
          </Button>
        </form>

        {/* Auth mode toggle */}
        <p className="mt-4 text-center text-sm text-login-card-foreground/90">
          {isSignIn ? "New here?" : "Already have an account?"}{" "}
          <button
            type="button"
            className="font-medium underline underline-offset-4"
            onClick={() => setMode(isSignIn ? "signup" : "signin")}
          >
            {isSignIn ? "Create an account" : "Sign in"}
          </button>
        </p>
      </CardContent>
    </Card>
  )
}
